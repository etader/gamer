var Nulumia = window.Nulumia || {};

! function ($, window, document, _undefined)
{
	Nulumia.Slider = XF.Element.newHandler(
	{
		options:
		{
			item: 5,
			itemWide: 3,
			itemMedium: 2,
			itemNarrow: 1,
			autoWidth: false,
			slideMove: 1,
			slideMargin: 0,
			addClass: '',
			mode: 'slide',
			useCSS: true,
			cssEasing: 'ease',
			easing: 'linear',
			speed: 400,
			auto: true,
			pauseOnHover: true,
			loop: true,
			slideEndAnimation: true,
			pause: 4000,
			keyPress: false,
			controls: true,
			prevHtml: '',
			nextHtml: '',
			adaptiveHeight: false,
			vertical: false,
			verticalHeight: 500,
			vThumbWidth: 100,
			thumbItem: 5,
			pager: true,
			gallery: false,
			galleryMargin: 5,
			thumbMargin: 5,
			currentPagerPosition: 'middle',
			enableTouch: true,
			enableDrag: true,
			freeMove: true,
			responsive : []
		},

		init: function ()
		{
			if ($.fn.lightSlider)
			{
				var responsive = [];
				
				if (this.options.itemWide)
				{
					responsive.push(
					{
						breakpoint: 900,
						settings:
						{
							item: this.options.itemWide,
							slideMove: 1
						}
					});
				}

				if (this.options.itemMedium)
				{
					responsive.push(
					{
						breakpoint: 650,
						settings:
						{
							item: this.options.itemMedium,
							slideMove: 1,
							thumbItem: 4,
							galleryMargin: 10,
							thumbMargin: 10
						}
					});
				}

				if (this.options.itemNarrow)
				{
					responsive.push(
					{
						breakpoint: 480,
						settings:
						{
							item: this.options.itemNarrow,
							slideMove: 1,
							vertical: false,
							gallery: false,
							adaptiveHeight: true
						}
					});
				}

				this.$target.lightSlider(
				{
					item: this.options.item,
					itemWide: this.options.itemWide,
					itemMedium: this.options.itemMedium,
					itemNarrow: this.options.itemNarrow,
					autoWidth: this.options.autoWidth,
					slideMove: this.options.slideMove,
					slideMargin: this.options.slideMargin,
					addClass: 'lightSlider--loaded',
					mode: this.options.mode,
					useCss: this.options.useCss,
					cssEasing: this.options.cssEasing,
					easing: this.options.easing,
					speed: this.options.speed,
					auto: this.options.auto,
					pauseOnHover: this.options.pauseOnHover,
					loop: this.options.loop,
					slideEndAnimation: this.options.slideEndAnimation,
					pause: this.options.pause,
					keyPress: this.options.keyPress,
					controls: this.options.controls,
					prevHtml: this.options.prevHtml,
					nextHtml: this.options.nextHtml,
					adaptiveHeight: this.options.adaptiveHeight,
					vertical: this.options.vertical,
					verticalHeight: this.options.verticalHeight,
					vThumbWidth: this.options.vThumbWidth,
					thumbItem: this.options.thumbItem,
					pager: this.options.pager,
					gallery: this.options.gallery,
					galleryMargin: this.options.galleryMargin,
					thumbMargin: this.options.thumbMargin,
					currentPagerPosition: this.options.currentPagerPosition,
					enableTouch: this.options.enableTouch,
					enableDrag: this.options.enableDrag,
					freeMove: this.options.freeMove,
					rtl: XF.isRtl(),
					responsive: responsive
				});
			}
			else
			{
				console.error('Lightslider must be loaded first.');
			}
		}
	});

	XF.Element.register('nl-slider', 'Nulumia.Slider');
}
(window.jQuery, window, document);